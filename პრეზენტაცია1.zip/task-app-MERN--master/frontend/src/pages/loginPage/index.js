import LoginPage from './loginPage';

export default LoginPage;
