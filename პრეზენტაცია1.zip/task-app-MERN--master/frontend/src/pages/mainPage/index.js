import MainPage from './mainPage';

export default MainPage;
