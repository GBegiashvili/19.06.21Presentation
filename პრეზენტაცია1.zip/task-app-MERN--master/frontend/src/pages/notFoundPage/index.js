import NotFoundPage from './notFoundPage';

export default NotFoundPage;
