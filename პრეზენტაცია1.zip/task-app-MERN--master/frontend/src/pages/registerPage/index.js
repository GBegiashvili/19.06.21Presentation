import RegisterPage from './registerPage';

export default RegisterPage;
