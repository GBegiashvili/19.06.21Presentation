import RegisterForm from './registerForm';

export default RegisterForm;
