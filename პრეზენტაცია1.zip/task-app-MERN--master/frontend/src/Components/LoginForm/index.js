import LoginForm from './loginForm';

export default LoginForm;
