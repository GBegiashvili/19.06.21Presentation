import InputBox from './InputBox';

export default InputBox;
