# task-app-MERN-

How to run project:

1) open backend folder in terminal
2) npm i
2) nodemon

This will run server on localhost:8080 

4) open frontend project in terminal
5) npm i
6) npm start

